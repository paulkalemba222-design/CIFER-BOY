# 𝗖𝗜𝗙𝗘𝗥 𝗠𝗗 — Vercel + Worker

## Architecture

Le projet est séparé en deux parties :

- `api/` : endpoints déployables sur Vercel.
- `worker/` : le bot WhatsApp Baileys original, qui doit rester actif sur un hébergement Node persistant.

**Important : Vercel seul ne suffit pas pour garder ce bot WhatsApp actif en permanence.** Baileys maintient une connexion et une session persistantes, alors que les Functions Vercel ont une durée d'exécution limitée.

## Vercel

Importe le dossier du projet dans Vercel et ajoute :

```env
TELEGRAM_BOT_TOKEN=TON_TOKEN
TELEGRAM_WEBHOOK_SECRET=UNE_CLE_SECRETE
```

Après déploiement, `/` et `/api/health` vérifient que l'API est en ligne.

## Worker WhatsApp

Dans `worker/` :

```bash
npm install
npm start
```

Variables :

```env
PREFIXE=.
DOSSIER_AUTH=auth_baileys
NUMBER=225XXXXXXXXXX
USE_QR=false
LOG_LEVEL=silent
RECONNECT_DELAY=5000
TELEGRAM_BOT_TOKEN=TON_TOKEN
```

Le dossier `worker/auth_baileys` doit être conservé par l'hébergement du worker.

## Sécurité

Le ZIP original contenait un token Telegram réel dans `.env.example`. Cette version ne contient plus ce token.

**Révoque/régénère ce token auprès de BotFather avant utilisation**, puisqu'il a été exposé dans le ZIP original.

## Modifications

- `vercel.json` ajouté
- `api/health.js` ajouté
- `api/telegram-webhook.js` ajouté
- bot déplacé dans `worker/`
- configuration Node 20
- secrets retirés de `.env.example`
- README adapté
